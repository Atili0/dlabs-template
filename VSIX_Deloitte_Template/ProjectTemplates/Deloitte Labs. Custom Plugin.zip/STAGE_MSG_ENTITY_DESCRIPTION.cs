﻿using System;

namespace $safeprojectname$
{
    public class STAGE_MSG_ENTITY_DESCRIPTION
    {
    }
}
